import React from 'react'


const Calculator = () => {
    function add(a,b){
        let sum = a+b;
        return sum;
    
     }
     function sub(a,b){
        let sub = a-b;
        return sub;
    
     }
     function mult(a,b){
        let mult = a*b;
        return mult;
    
     }
     function div(a,b){
        let div = a/b;
        div=div.toFixed(2);
        return div;
    
     }
    return (
        <>
            <div className="center_div">
                <ul>
                    <li> Sum of two number  =  {add(2, 3)}</li>
                    <li> Subtraction of two number  =  {sub(40, 4)}</li>
                    <li> Multipication of two number  = {mult(10, 3)}</li>
                    <li>Division  of two number =  {div(200, 5)}</li>
                </ul>
            </div>
        </>
    )
}

export default Calculator;
import React from 'react'
import Calculator from './Calculator';
import ContactForm from './ContactForm';
import DigitalClock from './DigitalClock';
import ToDoList from './ToDoList';

function App() {
  return (
   <>
     {/* { <DigitalClock/> } */}
     {/* <ContactForm/> */}
     <ToDoList/>
     {/* <Calculator/> */}
     </>
  )
}

export default App;